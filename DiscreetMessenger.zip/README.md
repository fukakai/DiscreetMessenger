# DiscreetMessenger
A Google Chrome Extension to disguise messenger appearance

French Only Available for now
